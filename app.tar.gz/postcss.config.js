// postcss.config.js (ESM-compatible)
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
  syntax: 'postcss-scss',
};
